# IMDB-Scrap-and-save-to-CSV-file

Scrap IMDB movie page and TV shows page then save the cleaned informations to CSV file

# Web Scrapping
Web scraping, web harvesting, or web data extraction is data scraping used for extracting data from websites. Web scraping software may access the World Wide Web directly using the Hypertext Transfer Protocol, or through a web browser


Here "IMBD TV show scrap to csv.py" scraps IMDB popular TV shows and saves it to structured csv file "TV_Shows"
and "IMDB Scrap Movies and save to csv" scraps IMDB popular Movies and saves it to structured csv file "Movies"

Site for TV shows :  http://www.imdb.com/chart/tvmeter

Site for Movies :    http://www.imdb.com/chart/moviemeter

## Next Work:

#### Working On: Scrap more details like : Summary , MetaScore , Gross , BoxOffice ,Runtime ,Language ,Adult Or Not . ...etc of more than 500 movies
